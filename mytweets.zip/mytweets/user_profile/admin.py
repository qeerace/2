# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from user_profile.models import User
admin.site.register(User)
# Register your models here.
